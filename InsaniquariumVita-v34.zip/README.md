# Insaniquarium Vita - loader for the Android port

Loads the Android `libmain.so` (armeabi-v7a) of Insaniquarium directly on a PS Vita: maps it into memory,
relocates it against Vita-side replacements for libc/SDL/GL, runs its C++ constructors and calls `SDL_main`.
Plays the PopCap (and optional SOE) intro videos on launch. The first line of `log.txt` shows the loader version.

This repository contains **no game files**. You need your own copy of the game.

## What you need
- A Vita with HENkaku and [kubridge](https://github.com/bythos14/kubridge) installed, and `libshacccg.suprx`
  (needed by vitaGL's runtime shader compiler).
- `libmain.so` from your own copy of the APK (`lib/armeabi-v7a/libmain.so`), placed in the project folder before
  building. It ends up next to `eboot.bin` in the VPK.
- The game's data files in `ux0:data/insaniquarium/` on the Vita (`properties/`, `images/`, ...).
- Optional intro videos, bundled into the VPK from `USRDIR/movies/popcap_logo.mp4` and `soe_logo.mp4`
  (H.264 + AAC, 960x544). A missing video is skipped.

## Build
Requires Docker. From the project folder:

    ./build.sh                    # release build -> build/InsaniquariumVita.vpk
    LOADER_DEBUG=ON ./build.sh    # same, with verbose diagnostics in log.txt

`build.sh` rebuilds vitaGL from source (pinned commit, `NO_SPLASHSCREEN=1`) so the vitaGL logo does not appear.
The version number lives in one place, `LOADER_VERSION` in `CMakeLists.txt`.

## Controls
| Vita | Game |
|---|---|
| Touch screen | mouse pointer / left click (the main-menu Quit button asks "Stop the insanity?" first: Quit exits, Cancel or Circle cancels) |
| Cross | right mouse button (at the last pointer position) |
| Triangle | Presto menu (same as right-clicking Presto; shows the cool-down message if it is still active) |
| Circle | backs out: closes the top dialog (Presto, options, confirmations, continue-level = Cancel), presses the "menu"/"back" button on the Help, level, pet, story and hall of fame screens ("back to the virtual tank" in the virtual tank store and on the virtual tank's pet-choosing screen; on the Help screen inside a level it returns to the Options menu, game still paused), or unpauses |
| Start | Space (pause) |
| Square | B (bubbles) |
| L / R | previous / next page on the Help screen, previous / next story on the pet/alien Story screen, previous / next tab (Adventure, Time Trial, Challenge, Personal) on the Hall of Fame |
| D-pad Up, held 1.5 s | on-screen keyboard (cheat codes); experimental |

## Optional settings: `ux0:data/insaniquarium/loader.cfg`
One `key=value` per line. Every value that is applied is echoed in `log.txt`.

    game_priority=160          worker_priority=160        cpu_mhz=444
    key_start=32               key_square=98              (ASCII codes, 0 disables)
    cross_right_click=1        (0 disables Cross = right-click)
    triangle_presto=1          (0 disables Triangle = Presto menu)
    circle_close=1             (0 disables Circle = close menus / unpause)
    help_lr=1                  (0 disables L/R on the Help, Story and Hall of Fame screens)
    quit_confirm=1             (0 = the main-menu Quit button exits without asking)
    cheat_keyboard=1           cheat_hold_ms=1500
    zero_memory=1              (0 turns off zero-filled allocations)
    skip_intro=0               (1 skips the videos)
    intro_volume=100           intro_audio_buffer=117     intro_bgm=0

## Game fixes applied by the loader
- Starvation death sound: guppies that starve now make the death sound like the other deaths do (the Android build passes "silent" for that one case; the loader changes it to "play sound").

## Troubleshooting
`ux0:data/insaniquarium/log.txt` is rewritten on every run. A crash is logged with addresses relative to the library
(`lib+...`) so it can be looked up in `libmain.so`. Failed file opens are logged; build with `LOADER_DEBUG=ON` for
the full trace, per-second video status and a memory/fps heartbeat.

## Source layout
    src/main.c          startup, fake JNIEnv, game thread, watchdog
    src/so_util.c       ELF loader + relocator (kubridge for executable memory)
    src/wrappers.c      bionic -> newlib shims, SDL event/pad handling, quit button
    src/gl_wrappers.c   float-argument GL wrappers handed out via SDL_GL_GetProcAddress
    src/intro_video.c   intro videos (SceAvPlayer video + audio)
    src/yuv_convert.h   YUV -> RGB converters for the intro video (NEON + scalar)
    src/unwind_hook.c   lets the C++ unwinder find libmain.so's exception tables
    src/import_table.c  generated from imports.txt by tools/gen_import_table.py

Not affiliated with PopCap, EA or Sony.
